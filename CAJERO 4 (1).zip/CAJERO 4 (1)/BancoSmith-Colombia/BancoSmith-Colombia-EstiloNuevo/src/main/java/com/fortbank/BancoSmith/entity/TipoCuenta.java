package com.fortbank.BancoSmith.entity;

public enum TipoCuenta 
{
    AHORROS,
    CORRIENTE
}
