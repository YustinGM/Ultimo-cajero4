package com.fortbank.BancoSmith.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fortbank.BancoSmith.entity.Cuenta;
import com.fortbank.BancoSmith.entity.Movimiento;

public interface MovimientoRepository extends JpaRepository<Movimiento, Long >
{
    List<Movimiento> findByCuenta(Cuenta cuenta);
    List<Movimiento> findByCuentaOrderByFechaDesc(Cuenta cuenta);
}
