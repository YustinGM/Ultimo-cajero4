package com.fortbank.BancoSmith.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.fortbank.BancoSmith.entity.Cliente;
import com.fortbank.BancoSmith.entity.Cuenta;
import java.util.List;


public interface CuentaRepository extends JpaRepository<Cuenta, Long> 
{
    Optional<Cuenta>findByNumero(String numero);
    List<Cuenta>findByCliente(Cliente cliente);
}
