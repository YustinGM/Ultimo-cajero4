
-- Base de datos para Banco Smith - Completa y compatible con phpMyAdmin

DROP DATABASE IF EXISTS banco_smith;
CREATE DATABASE banco_smith;
USE banco_smith;

-- Tabla de clientes
CREATE TABLE cliente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    identificacion VARCHAR(50) NOT NULL UNIQUE,
    pin VARCHAR(100) NOT NULL,
    bloqueado BOOLEAN DEFAULT FALSE,
    intentos_fallidos INT DEFAULT 0
);

-- Tabla de cuentas
CREATE TABLE cuenta (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(20) NOT NULL UNIQUE,
    saldo DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    tipo VARCHAR(20) NOT NULL,
    cliente_id INT NOT NULL,
    FOREIGN KEY (cliente_id) REFERENCES cliente(id)
);

-- Tabla de movimientos
CREATE TABLE movimiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    tipo VARCHAR(20) NOT NULL,
    monto DECIMAL(15,2) NOT NULL,
    cuenta_id INT NOT NULL,
    FOREIGN KEY (cuenta_id) REFERENCES cuenta(id)
);

-- Tabla de desbloqueos (registro histórico de desbloqueos)
CREATE TABLE desbloqueo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    administrador VARCHAR(100),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES cliente(id)
);

-- Insertar cliente de prueba
INSERT INTO cliente (nombre, identificacion, pin, bloqueado, intentos_fallidos)
VALUES ('Yolanda Caicedo', '123456789', '1234', FALSE, 0);

-- Insertar cuenta de prueba
INSERT INTO cuenta (numero, saldo, tipo, cliente_id)
VALUES ('100200300', 500000.00, 'AHORROS', 1);

-- Insertar movimiento de prueba
INSERT INTO movimiento (fecha, tipo, monto, cuenta_id)
VALUES (NOW(), 'CONSIGNACION', 500000.00, 1);
